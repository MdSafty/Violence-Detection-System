import random
import cv2
import numpy as np
from ultralytics import YOLO
from deepface import DeepFace


# Some libray function
def calculateViolence(object_list, face_expression_max):
    points = 10
    targetObject = [ "Chapati", "Fire", "Gun", "Knife", "Rifle"]

    for item in object_list:
        if item in targetObject:
            points +=5

    if('Knife' in object_list) :
        points += 15

    if('Gun' in object_list) :
        points += 15

    if('Chapati' in object_list) :
        points += 20

    if('Knife' in object_list and face_expression_max == "angry") : 
        points += 40

    if('Gun' in object_list  and face_expression_max == "angry") : 
        points += 40
    
    if('Gun' in object_list and face_expression_max == "neutral") : 
        points += 40

    if('Car' in object_list and object_list['Fire']) : 
        points += 25
    
    if('Car' in object_list and object_list['Fire'] & face_expression_max == "angry") : 
        points += 60
    if('Person' in object_list and face_expression_max == "neutral"):
        points += 5
    if('Person' in object_list and face_expression_max == "angry"):
        points += 25
  
    
    return points


def getLikert_scale(total_score) :

    # Define Likert scale categories
    if total_score <= 20:
        likert_scale = "Very Low"
    elif total_score <= 40:
        likert_scale = "Low"
    elif total_score <= 60:
        likert_scale = "Moderate"
    elif total_score <= 75:
        likert_scale = "High"
    else:
        likert_scale = "Very High"
    
    return total_score, likert_scale



emotions = {'angry': 0, 'disgust': 0, 'fear': 0, 'happy': 0, 'sad': 0, 'surprise': 0, 'neutral': 0}
targetObject = [ "Chapati", "Fire", "Gun", "Knife", "Rifle"]
resultPoints = 0
resultScale = "Very Low"

def countUp(x):
    if x == "angry":
        emotions["angry"] += 1
    elif x == "disgust":
        emotions["disgust"] += 1
    elif x == "fear":
        emotions["fear"] += 1
    elif x == "happy":
        emotions["happy"] += 1
    elif x == "sad":
        emotions["sad"] += 1
    elif x == "surprise":
        emotions["surprise"] += 1
    elif x == "neutral":
        emotions["neutral"] += 1
    else:
        0
    return 0

def resetEmotion():
    emotions["angry"] = 0
    emotions["disgust"] = 0
    emotions["fear"] = 0
    emotions["happy"] = 0
    emotions["sad"] = 0
    emotions["surprise"] = 0
    emotions["neutral"] = 0


# import Haarcascade anotation
faceCascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# opening the file in read mode
my_file = open("classes.txt", "r")
# reading the file
data = my_file.read()
# replacing end splitting the text | when newline ('\n') is seen.
class_list = data.split("\n")
my_file.close()

# print(class_list)

# Generate random colors for class list
detection_colors = []
for i in range(len(class_list)):
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)
    detection_colors.append((b, g, r))



# load a pretrained YOLOv8n model
model = YOLO("weights/best.pt", "v8")

# Vals to resize video frames | small frame optimise the run
frame_wid = 640
frame_hyt = 480




font = cv2.FONT_HERSHEY_SIMPLEX




# ------------------------- For Video Started ----------------------

# Analyze from Video
cap = cv2.VideoCapture('./test/a.mp4')

if not cap.isOpened():
    print("Cannot open camera")
    exit()

# Define the codec and create a VideoWriter object
fourcc = cv2.VideoWriter_fourcc(*'XVID')  # Codec for saving video (use XVID for .avi format)
out = cv2.VideoWriter('output_video.avi', fourcc, 30, (frame_wid, frame_hyt))

# Number of rounds you want the loop to repeat
flagStart = 0
flagEnd = 6
emotions = {'angry': 0, 'disgust': 0, 'fear': 0, 'happy': 0, 'sad': 0, 'surprise': 0, 'neutral': 0}
isDecisionMade = False
decision = ""

while True:
    # Capture frame-by-frame
    ret, frame = cap.read()
    # if frame is read correctly ret is True


    # if(flagStart < flagEnd): 
    #         flagStart +=1
    #         print(flagStart)



        # Loop through a range and repeat the loop for the specified number of rounds


# Facial Expression 
    result = DeepFace.analyze(frame, actions = ['emotion'], enforce_detection=False)
    countUp(result[0]['dominant_emotion'])

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
#print(faceCascade.empty())

    faces = faceCascade.detectMultiScale(gray, 1.1,4)
    font = cv2.FONT_HERSHEY_SIMPLEX

    # Draw a rectangle around the faces
    for(x, y, w, h) in faces:
        cv2.rectangle(frame, (x,y), (x+w, y+h), (0,255,0), 2)
        # Use putText() method for inserting text on video
        # cv2.putText(frame,
        #     result[0]['dominant_emotion'],
        #         (x+10, y+30),
        #         font, 2,
        #         (0,0,255),
        #         2,
        #         cv2.LINE_4
        #     )

    if not ret:
        print("Can't receive frame (stream end?). Exiting ...")
        break



    # Predict on image
    detect_params = model.predict(source=[frame], conf=0.3, save=False)

    # Convert tensor array to numpy
    DP = detect_params[0].numpy()
    # print(DP)

    if len(DP) != 0:
        for i in range(len(detect_params[0])):
            print(i)

            boxes = detect_params[0].boxes
            box = boxes[i]  # returns one box
            clsID = box.cls.numpy()[0]
            conf = box.conf.numpy()[0]
            bb = box.xyxy.numpy()[0]

            cv2.rectangle(
                frame,
                (int(bb[0]), int(bb[1])),
                (int(bb[2]), int(bb[3])),
                detection_colors[int(clsID)],
                3,
            )

            # Display class name and confidence
            font = cv2.FONT_HERSHEY_COMPLEX
            cv2.putText(
                frame,
                class_list[int(clsID)] + " " + str(round(conf, 3)) + "%",
                (int(bb[0]), int(bb[1]) - 10),
                font,
                1,
                (255, 255, 255),
                2,
            )
        # max_key = max(emotions, key=lambda k: emotions[k])
        max_key = result[0]['dominant_emotion']
        # Check if a value is present in the list
        value_to_check = class_list[int(clsID)]
        foundObj = ""
        object_lists = []
        if value_to_check in targetObject:
            targetHit = True
            foundObj = class_list[int(clsID)]
            object_lists.append(foundObj)
            print(f"{value_to_check} is in the list.")
        else:
            targetHit = False
            print(f"{value_to_check} is NOT in the list.")
        resultPoints = calculateViolence(object_lists, max_key)
    points, resultScale = getLikert_scale(resultPoints) 
    print(points)
    resultPoints = 10
    cv2.putText(
                frame,
                # "Violence Level" + " " + str(max_key) + str(foundObj) + "%",
                "Violence Level: " + " " + str(resultScale),
                (0 + 60, 0 + 60),
                font,
                1,
                (0, 0, 255),
                2,
            )    
                
    # elif (flagStart == flagEnd):
    #     resetEmotion()
    #     flagStart = 0
    # else :
    #     flagStart = 0
    # Display the resulting frame
     # Write the processed frame to the output video
    out.write(frame)
    cv2.imshow("ViolanceDetection", frame)

    # Terminate run when "Q" pressed
    if cv2.waitKey(1) == ord("q"):
        break

# When everything done, release the capture
cap.release()
out.release()
cv2.destroyAllWindows()


# -------------------------- Web Cam Ended --------------------------------------
# -------------------------- Video File Ended -----------------------------------
