import random
import os
import cv2
import numpy as np
from ultralytics import YOLO
from deepface import DeepFace



# Some libray function
def calculateViolence(object_list, face_expression_max):
    points = 10

    if('Knife' in object_list) :
        points = 15

    if('Gun' in object_list) :
        points = 15

    if('Chapati knife' in object_list) :
        points = 20

    if('Knife' in object_list & face_expression_max == "angry") : 
        points = 40

    if('Gun' in object_list & face_expression_max == "angry") : 
        points = 40
    
    if('Gun' in object_list & face_expression_max == "neutral") : 
        points = 40

    if('Car' in object_list & object_list['Fire']) : 
        points = 25
    
    if('Car' in object_list & object_list['Fire'] & face_expression_max == "angry") : 
        points = 60
    if('Person' in object_list & face_expression_max == "neutral"):
        points = 5
    if('Person' in object_list & face_expression_max == "angry"):
        points = 25
  
    
    return points


def getLikert_scale(total_score) :

    # Define Likert scale categories
    if total_score <= 20:
        likert_scale = "Very Low"
    elif total_score <= 40:
        likert_scale = "Low"
    elif total_score <= 60:
        likert_scale = "Moderate"
    elif total_score <= 75:
        likert_scale = "High"
    else:
        likert_scale = "Very High"
    
    return total_score, likert_scale



emotions = {'angry': 0, 'disgust': 0, 'fear': 0, 'happy': 0, 'sad': 0, 'surprise': 0, 'neutral': 0}
targetObject = [ "Chapati", "Fire", "Gun", "Knife", "Rifle"]
resultPoints = 0
resultScale = "Very Low"

def countUp(x):
    if x == "angry":
        emotions["angry"] += 1
    elif x == "disgust":
        emotions["disgust"] += 1
    elif x == "fear":
        emotions["fear"] += 1
    elif x == "happy":
        emotions["happy"] += 1
    elif x == "sad":
        emotions["sad"] += 1
    elif x == "surprise":
        emotions["surprise"] += 1
    elif x == "neutral":
        emotions["neutral"] += 1
    else:
        0
    return 0

def resetEmotion():
    emotions["angry"] = 0
    emotions["disgust"] = 0
    emotions["fear"] = 0
    emotions["happy"] = 0
    emotions["sad"] = 0
    emotions["surprise"] = 0
    emotions["neutral"] = 0




# import Haarcascade anotation
faceCascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# opening the file in read mode
my_file = open("classes.txt", "r")
# reading the file
data = my_file.read()
# replacing end splitting the text | when newline ('\n') is seen.
class_list = data.split("\n")
my_file.close()

# print(class_list)

# Generate random colors for class list
detection_colors = []
for i in range(len(class_list)):
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)
    detection_colors.append((b, g, r))

# load a pretrained YOLOv8n model
model = YOLO("weights/best.pt", "v8")

# Vals to resize video frames | small frame optimise the run
frame_wid = 640
frame_hyt = 480


# Detect From Images

image_path = "test/2.jpg"
frame = cv2.imread(image_path)
gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

# if frame is read correctly ret is True

# Facial Expression 
result = DeepFace.analyze(frame, actions = ['emotion'], enforce_detection=False)

gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
#print(faceCascade.empty())

faces = faceCascade.detectMultiScale(gray, 1.1,4)
font = cv2.FONT_HERSHEY_SIMPLEX

# Draw a rectangle around the faces
for(x, y, w, h) in faces:
    cv2.rectangle(frame, (x,y), (x+w, y+h), (0,255,0), 2)
    # Use putText() method for inserting text on video
    cv2.putText(frame,
            result[0]['dominant_emotion'],
            (x+10, y+30),
            font, 2,
            (0,0,255),
            2,
            cv2.LINE_4
            )



#  resize the frame | small frame optimise the run
# frame = cv2.resize(frame, (frame_wid, frame_hyt))

# Predict on image
detect_params = model.predict(source=[frame], conf=0.3, save=True)

# Convert tensor array to numpy
DP = detect_params[0].numpy()

if len(DP) != 0:
    for i in range(len(detect_params[0])):
        print(i)

        boxes = detect_params[0].boxes
        box = boxes[i]  # returns one box
        clsID = box.cls.numpy()[0]
        conf = box.conf.numpy()[0]
        bb = box.xyxy.numpy()[0]

        cv2.rectangle(
            frame,
            (int(bb[0]), int(bb[1])),
            (int(bb[2]), int(bb[3])),
            detection_colors[int(clsID)],
            3,
        )

        # Display class name and confidence
        font = cv2.FONT_HERSHEY_COMPLEX
        cv2.putText(
            frame,
            class_list[int(clsID)] + " " + str(round(conf, 3)) + "%",
            (int(bb[0]), int(bb[1]) - 10),
            font,
            1,
            (255, 255, 255),
            2,
        )
        max_key = max(emotions, key=lambda k: emotions[k])
        # Check if a value is present in the list
        value_to_check = class_list[int(clsID)]
        foundObj = ""
        object_lists = []

        if value_to_check in targetObject:
            targetHit = True
            foundObj = class_list[int(clsID)]
            object_lists.append(foundObj)
            print(f"{value_to_check} is in the list.")
        else:
            targetHit = False
            print(f"{value_to_check} is NOT in the list.")
        resultPoints = calculateViolence(object_lists, max_key)

points, resultScale = getLikert_scale(resultPoints)    

cv2.putText(
            frame,
            # "Violence Level" + " " + str(max_key) + str(foundObj) + "%",
            "Violence Level :" + " " + str(resultScale),
            (0 + 60, 0 + 60),
            font,
            2,
            (0, 0, 255),
            2,
        ) 


# Specify the output directory and filename for the analyzed image
output_directory = 'output_images'
output_filename = 'analyzed_image.jpg'


os.makedirs(output_directory, exist_ok=True)

# Save the analyzed image to the output directory
output_path = os.path.join(output_directory, output_filename)
cv2.imwrite(output_path, frame)

print(f'Analyzed image saved to {output_path}')

# Display the resulting frame
cv2.imshow("ViolanceDetection", frame)


cv2.destroyAllWindows()
