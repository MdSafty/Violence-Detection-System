import requests
import time

endpoint_url = "https://ambition-cloud.com"
total_requests = 1000000

# Get the current time before the loop
start_time = time.time()

for i in range(total_requests):
    response = requests.get(endpoint_url)
    if response.status_code == 200:
        print(f"Request {i+1} successful")

# Get the current time after the loop
end_time = time.time()


# Calculate the time difference
time_difference = end_time - start_time

print(f"Time taken for the loop: {time_difference} seconds")