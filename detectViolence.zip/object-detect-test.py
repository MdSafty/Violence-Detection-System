from ultralytics import YOLO

# load a pretrained YOLOv8n model
model = YOLO("weights/best.pt", "v8")

frame = "./test/2.jpg"

# Predict on image
detect_params = model.predict(source=[frame], conf=0.45, save=True)
